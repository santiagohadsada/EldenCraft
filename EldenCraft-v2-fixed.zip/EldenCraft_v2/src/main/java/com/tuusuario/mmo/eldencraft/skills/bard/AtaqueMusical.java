package com.tuusuario.mmo.eldencraft.skills.bard;

import com.tuusuario.mmo.eldencraft.skills.Skill;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.Sound;
import org.bukkit.Particle;

public class AtaqueMusical implements Skill {
    @Override public String getName() { return "Ataque Musical"; }
    @Override public double getCost() { return 45.0; }
    @Override public int getLevelRequired() { return 16; }

    @Override
    public void execute(Player player, PlayerData data) {
        // Daño aumentado (antes 10 + CHA*0.5)
        double damage = 14.0 + (data.getCharisma() * 0.6);
        player.getNearbyEntities(7, 7, 7).forEach(e -> {
            if (e instanceof LivingEntity target && e != player) {
                target.damage(damage, player);
                target.getWorld().spawnParticle(Particle.NOTE,
                        target.getLocation().add(0, 1, 0), 8);
            }
        });
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASEDRUM, 1f, 0.5f);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
    }
}
