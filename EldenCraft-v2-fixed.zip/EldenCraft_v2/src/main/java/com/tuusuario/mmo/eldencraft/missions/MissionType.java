package com.tuusuario.mmo.eldencraft.missions;

// Tipos de objetivo de mision soportados.
public enum MissionType {
    KILL,    // Matar mobs
    GATHER,  // Picar / recoger bloques
    FISH,    // Pescar
    BREED,   // Criar animales
    TRAVEL,  // Caminar bloques
    CRAFT    // Craftear items
}
