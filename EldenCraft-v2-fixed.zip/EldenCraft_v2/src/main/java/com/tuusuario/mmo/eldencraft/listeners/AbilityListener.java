package com.tuusuario.mmo.eldencraft.listeners;

import com.tuusuario.mmo.eldencraft.EldenCraft;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import com.tuusuario.mmo.eldencraft.skills.Skill;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class AbilityListener implements Listener {

    private final EldenCraft plugin;
    private final Set<UUID> menuAbierto = new HashSet<>();

    // Cooldowns: UUID del jugador -> (clave "CLASE_SLOT" -> timestamp ms del último uso)
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    // Cooldowns en segundos por slot 1-7
    private static final int[] COOLDOWN_SEGUNDOS = {0, 8, 10, 12, 15, 20, 25, 120};

    public AbilityListener(EldenCraft plugin) {
        this.plugin = plugin;

        // Tarea que mantiene el menu visible mientras este abierto.
        // El HUD principal corre cada 20 ticks; este corre cada 10 para
        // ganar la "carrera" y mantener la action bar siempre con el menu.
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (menuAbierto.isEmpty()) return;
            for (UUID id : menuAbierto) {
                Player player = Bukkit.getPlayer(id);
                if (player != null && player.isOnline()) {
                    mostrarHabilidades(player);
                }
            }
        }, 5L, 10L);
    }

    // Indica si el jugador tiene el menu de habilidades abierto (lo usa el HUD).
    public boolean isMenuOpen(UUID uuid) {
        return menuAbierto.contains(uuid);
    }

    @EventHandler
    public void onPressF(PlayerSwapHandItemsEvent event) {
        event.setCancelled(true);
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        if (menuAbierto.contains(uuid)) {
            menuAbierto.remove(uuid);
            player.sendActionBar(ChatColor.RED + "✖ Menú de Habilidades Cerrado");
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 0.5f);
        } else {
            menuAbierto.add(uuid);
            mostrarHabilidades(player);
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.5f);
        }
    }

    @EventHandler
    public void onNumberPress(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        if (!menuAbierto.contains(player.getUniqueId())) return;

        event.setCancelled(true);

        int slot = event.getNewSlot() + 1;

        if (slot >= 1 && slot <= 7) {
            PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
            if (data == null || data.getPlayerClass() == null) return;

            Skill skill = plugin.getSkillManager().getSkill(data.getPlayerClass(), slot);

            if (skill != null) {
                // 1. Verificar Nivel
                if (data.getLevel() < skill.getLevelRequired()) {
                    player.sendMessage(ChatColor.RED + "¡Necesitas nivel " + skill.getLevelRequired()
                            + " para usar " + skill.getName() + "!");
                    return;
                }

                // 2. Verificar Cooldown
                String cdKey = data.getPlayerClass().name() + "_" + slot;
                long ahora = System.currentTimeMillis();
                Map<String, Long> misCD = cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>());
                long ultimoUso = misCD.getOrDefault(cdKey, 0L);
                int cdSegundos = (slot < COOLDOWN_SEGUNDOS.length) ? COOLDOWN_SEGUNDOS[slot] : 10;

                if (ahora - ultimoUso < cdSegundos * 1000L) {
                    long restante = (cdSegundos * 1000L - (ahora - ultimoUso)) / 1000 + 1;
                    player.sendMessage(ChatColor.RED + "⏳ " + skill.getName()
                            + " en recarga: " + restante + "s");
                    return;
                }

                // 3. Verificar Recurso (Maná/Energía)
                if (data.getCurrentResource() < skill.getCost()) {
                    String tipo = esMagico(data) ? "Maná" : "Energía";
                    player.sendMessage(ChatColor.RED + "¡No tienes suficiente " + tipo + "!");
                    return;
                }

                // 4. Ejecutar habilidad
                data.setCurrentResource(data.getCurrentResource() - skill.getCost());
                data.setFatigue(data.getFatigue() + (int)(skill.getCost() / 2));
                misCD.put(cdKey, ahora);

                skill.execute(player, data);

                player.sendActionBar(ChatColor.GREEN + "✔ " + skill.getName()
                        + ChatColor.GRAY + " (CD: " + cdSegundos + "s)");
                menuAbierto.remove(player.getUniqueId());

            } else {
                player.sendMessage(ChatColor.GRAY + "Aún no hay una habilidad programada en este espacio.");
            }
        }
    }

    private void mostrarHabilidades(Player player) {
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        if (data == null || data.getPlayerClass() == null) return;

        String clase = data.getPlayerClass().name();
        int nivel = data.getLevel();
        int[] hitos = {1, 3, 6, 9, 12, 16, 20};

        Map<String, Long> misCD = cooldowns.getOrDefault(player.getUniqueId(), new HashMap<>());
        long ahora = System.currentTimeMillis();

        StringBuilder menu = new StringBuilder(ChatColor.GOLD + "" + ChatColor.BOLD + clase + " ");

        for (int i = 0; i < hitos.length; i++) {
            int slotNum = i + 1;
            String cdKey = clase + "_" + slotNum;
            int cdSeg = (slotNum < COOLDOWN_SEGUNDOS.length) ? COOLDOWN_SEGUNDOS[slotNum] : 10;
            boolean enCD = (ahora - misCD.getOrDefault(cdKey, 0L)) < cdSeg * 1000L;

            if (nivel < hitos[i]) {
                menu.append(ChatColor.DARK_GRAY).append(slotNum).append(" "); // Bloqueada
            } else if (enCD) {
                menu.append(ChatColor.RED).append(slotNum).append(" ");       // En recarga
            } else {
                menu.append(ChatColor.GREEN).append(slotNum).append(" ");     // Disponible
            }
        }

        menu.append(ChatColor.WHITE).append("| [F] Salir");
        player.sendActionBar(menu.toString());
    }

    private boolean esMagico(PlayerData data) {
        String clase = data.getPlayerClass().name();
        return clase.equals("MAGE") || clase.equals("PALADIN") || clase.equals("BARD");
    }
}
