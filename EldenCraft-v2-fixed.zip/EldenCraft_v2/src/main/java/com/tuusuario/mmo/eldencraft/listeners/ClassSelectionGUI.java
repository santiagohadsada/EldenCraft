package com.tuusuario.mmo.eldencraft.listeners;

import com.tuusuario.mmo.eldencraft.EldenCraft;
import com.tuusuario.mmo.eldencraft.models.ClassType;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ClassSelectionGUI implements Listener {

    private final EldenCraft plugin;
    private final String title = "§8➤ §lSelecciona tu Clase";

    public ClassSelectionGUI(EldenCraft plugin) {
        this.plugin = plugin;
    }

    public void openClassMenu(Player player) {
        Inventory gui = Bukkit.createInventory(null, 9, title);

        gui.setItem(1, createItem(Material.IRON_SWORD,        "§c§lGUERRERO",   "§7Maestros del cuerpo a cuerpo.", "§6Recurso: Energia"));
        gui.setItem(2, createItem(Material.BLAZE_ROD,         "§b§lMAGO",       "§7Maestros de la magia.",         "§3Recurso: Mana"));
        gui.setItem(3, createItem(Material.BOW,               "§a§lEXPLORADOR", "§7Maestros de la caza.",          "§6Recurso: Energia"));
        gui.setItem(4, createItem(Material.GOLDEN_CHESTPLATE, "§e§lPALADIN",    "§7Guerreros sagrados.",           "§3Recurso: Mana"));
        gui.setItem(5, createItem(Material.IRON_NUGGET,       "§8§lLADRON",     "§7Maestros del sigilo.",          "§6Recurso: Energia"));
        gui.setItem(6, createItem(Material.JUKEBOX,           "§d§lBARDO",      "§7Maestros de la musica.",        "§3Recurso: Mana"));
        gui.setItem(7, createItem(Material.NETHERITE_AXE,     "§4§lBARBARO",    "§7Guerreros feroces.",            "§6Recurso: Energia"));

        player.openInventory(gui);
    }

    private ItemStack createItem(Material material, String name, String desc, String recurso) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        List<String> lore = new ArrayList<>();
        lore.add(desc);
        lore.add(recurso);
        lore.add("");
        lore.add("§e¡Haz clic para elegir!");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!event.getView().getTitle().equals(title)) return;
        event.setCancelled(true);

        if (event.getCurrentItem() == null) return;
        Player player = (Player) event.getWhoClicked();
        String name = event.getCurrentItem().getItemMeta().getDisplayName();
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        if (data == null) return;

        if      (name.contains("GUERRERO"))   data.setPlayerClass(ClassType.WARRIOR);
        else if (name.contains("MAGO"))       data.setPlayerClass(ClassType.MAGE);
        else if (name.contains("EXPLORADOR")) data.setPlayerClass(ClassType.RANGER);
        else if (name.contains("PALADIN"))    data.setPlayerClass(ClassType.PALADIN);
        else if (name.contains("LADRON"))     data.setPlayerClass(ClassType.ROGUE);
        else if (name.contains("BARDO"))      data.setPlayerClass(ClassType.BARD);
        else if (name.contains("BARBARO"))    data.setPlayerClass(ClassType.BARBARIAN);
        else return;

        com.tuusuario.mmo.eldencraft.managers.ExperienceManager.applyMaxHealth(player, data);
        player.closeInventory();
        player.sendMessage("§a¡Ahora eres un " + name + "§a!");
        player.sendMessage("§7Tu aventura comienza ahora. Pulsa §f[F] §7para ver tus habilidades.");
        player.sendMessage("§7Usa §f/missions §7para ver tus misiones y §f/shop §7para abrir la tienda.");
    }
}
