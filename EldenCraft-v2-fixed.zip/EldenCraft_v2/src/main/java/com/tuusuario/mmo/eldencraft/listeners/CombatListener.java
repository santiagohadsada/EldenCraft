package com.tuusuario.mmo.eldencraft.listeners;

import com.tuusuario.mmo.eldencraft.EldenCraft;
import com.tuusuario.mmo.eldencraft.managers.PartyManager;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import com.tuusuario.mmo.eldencraft.util.BalanceState;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

// Listener central de combate.
public class CombatListener implements Listener {

    private final EldenCraft plugin;

    public CombatListener(EldenCraft plugin) {
        this.plugin = plugin;
    }

    // Daño hecho por jugador.
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        // 1) Friendly fire OFF en la misma party (melee y cualquier daño con Player como fuente directa)
        if (event.getEntity() instanceof Player) {
            Player victim = (Player) event.getEntity();
            Player attacker = getPlayerSource(event);
            if (attacker != null && !attacker.equals(victim)) {
                PartyManager pm = plugin.getPartyManager();
                PartyManager.Party pa = pm.getParty(attacker.getUniqueId());
                PartyManager.Party pv = pm.getParty(victim.getUniqueId());
                if (pa != null && pv != null && pa == pv) {
                    event.setCancelled(true);
                    attacker.sendActionBar(ChatColor.GREEN
                            + "✦ Fuego amigo desactivado: " + victim.getName() + " es de tu party.");
                    return;
                }
            }
        }

        if (!(event.getDamager() instanceof Player)) return;
        Player player = (Player) event.getDamager();
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        if (data == null) return;

        // 2) Bonus por Fuerza
        double damageBase = event.getDamage();
        double extra = damageBase * (data.getStrength() / 10.0);

        // 3) Crítico marcado del Pícaro (consume el flag)
        Double critMult = BalanceState.rogueCritNext.remove(player.getUniqueId());
        if (critMult != null && critMult > 1.0) {
            extra += damageBase * (critMult - 1.0);
            player.getWorld().spawnParticle(Particle.CRIT,
                    event.getEntity().getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.05);
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 1.4f);
            String etiqueta = critMult >= 4.0 ? "§4§l¡DOBLE CRÍTICO!" : "§e§l¡CRÍTICO!";
            player.sendActionBar(etiqueta);
        }

        event.setDamage(damageBase + extra);

        // 4) Lifesteal del Guerrero (Postura de Combate): +1 HP por golpe
        if (BalanceState.hasLifesteal(player.getUniqueId())) {
            double maxHp = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
            player.setHealth(Math.min(maxHp, player.getHealth() + 1.0));
            player.getWorld().spawnParticle(Particle.HEART,
                    player.getLocation().add(0, 1.6, 0), 1);
        }
    }

    // Daño recibido por jugador: bárbaro berserk x2, guerrero parry refleja (melee + magia + proyectiles).
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onDamageReceived(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player victim = (Player) event.getEntity();

        // Bárbaro berserk: recibe x2
        if (BalanceState.isBerserk(victim.getUniqueId())) {
            event.setDamage(event.getDamage() * 2.0);
        }

        // Guerrero contraataque: 50% reflejado al atacante (melee, proyectiles Y magia)
        if (BalanceState.isParrying(victim.getUniqueId())) {
            LivingEntity reflectTarget = null;

            // Caso 1: atacante directo es LivingEntity (melee y hechizos con entity.damage(dmg, player))
            if (event.getDamager() instanceof LivingEntity && event.getDamager() != victim) {
                reflectTarget = (LivingEntity) event.getDamager();
            }
            // Caso 2: proyectil (flecha, bola de fuego, etc.)
            else if (event.getDamager() instanceof Projectile) {
                Projectile proj = (Projectile) event.getDamager();
                ProjectileSource shooter = proj.getShooter();
                if (shooter instanceof LivingEntity && shooter != victim) {
                    reflectTarget = (LivingEntity) shooter;
                }
            }

            if (reflectTarget != null) {
                double reflect = event.getDamage() * 0.5;
                if (reflect > 0.5) {
                    reflectTarget.damage(reflect, victim);
                    reflectTarget.getWorld().spawnParticle(Particle.SWEEP_ATTACK,
                            reflectTarget.getLocation().add(0, 1, 0), 3);
                    reflectTarget.getWorld().playSound(reflectTarget.getLocation(),
                            Sound.ITEM_SHIELD_BLOCK, 1f, 1.5f);

                    // Robo de vida: el guerrero se cura el 25% del daño reflejado
                    double heal = reflect * 0.25;
                    double maxHp = victim.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
                    victim.setHealth(Math.min(maxHp, victim.getHealth() + heal));
                    victim.getWorld().spawnParticle(Particle.HEART,
                            victim.getLocation().add(0, 1.6, 0), 2, 0.3, 0.3, 0.3, 0);
                }
            }
        }
    }

    // Tótem Divino del Paladín: cancela muerte si hay un paladin con tótem activo cerca.
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLethalDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player victim = (Player) event.getEntity();
        if (victim.getHealth() - event.getFinalDamage() > 0) return;

        for (Player paladin : Bukkit.getOnlinePlayers()) {
            if (!paladin.getWorld().equals(victim.getWorld())) continue;
            if (paladin.getLocation().distance(victim.getLocation()) > 30.0) continue;
            if (!BalanceState.hasActiveTotem(paladin.getUniqueId())) continue;

            event.setCancelled(true);
            double maxHp = victim.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
            victim.setHealth(Math.max(1.0, maxHp * 0.5));
            victim.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 1));
            victim.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 1));
            victim.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING,
                    victim.getLocation().add(0, 1, 0), 80, 0.6, 1.2, 0.6, 0.4);
            victim.getWorld().playSound(victim.getLocation(),
                    Sound.ITEM_TOTEM_USE, 1f, 1f);

            BalanceState.paladinTotem.remove(paladin.getUniqueId());
            paladin.sendMessage(ChatColor.GOLD + "✦ Tu §e§lTótem Divino§r§6 ha salvado a "
                    + ChatColor.YELLOW + victim.getName() + ChatColor.GOLD + ".");
            if (!paladin.equals(victim)) {
                victim.sendMessage(ChatColor.GOLD + "✦ ¡El §e§lTótem Divino§r§6 de "
                        + paladin.getName() + " te ha salvado de la muerte!");
            }
            return;
        }
    }

    /**
     * Obtiene el jugador fuente de un evento de daño, ya sea como atacante directo
     * o como disparador de un proyectil. Útil para el friendly fire con hechizos.
     */
    private Player getPlayerSource(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player) {
            return (Player) event.getDamager();
        }
        if (event.getDamager() instanceof Projectile) {
            Projectile proj = (Projectile) event.getDamager();
            if (proj.getShooter() instanceof Player) {
                return (Player) proj.getShooter();
            }
        }
        return null;
    }
}
