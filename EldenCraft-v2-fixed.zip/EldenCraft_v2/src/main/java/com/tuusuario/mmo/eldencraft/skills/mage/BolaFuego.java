package com.tuusuario.mmo.eldencraft.skills.mage;
import com.tuusuario.mmo.eldencraft.skills.Skill;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.Sound;

public class BolaFuego implements Skill {
    public String getName() { return "Bola de Fuego"; }
    public double getCost() { return 15.0; }
    public int getLevelRequired() { return 1; }

    public void execute(Player player, PlayerData data) {
        Fireball fireball = player.launchProjectile(Fireball.class);
        // Daño un poco mayor
        float power = 1.6f + (float)(data.getIntelligence() / 12.0);
        fireball.setYield(power);
        fireball.setIsIncendiary(false);
        player.playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
    }
}
