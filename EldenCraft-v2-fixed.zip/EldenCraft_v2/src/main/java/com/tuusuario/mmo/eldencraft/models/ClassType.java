package com.tuusuario.mmo.eldencraft.models;
// Define las clases del juego, sus bonificadores de estadísticas y el tipo de recurso que consumen sus habilidades.
public enum ClassType {
    // Definición: Nombre, STR, DEX, CON, INT, WIS, CHA, Recurso
    WARRIOR("Guerrero", 3, 1, 2, 0, 0, -1, "ENERGIA"),
    MAGE("Mago", -1, 1, -1, 3, 2, 1, "MANA"),
    RANGER("Explorador", 1, 3, 1, 0, 2, 0, "ENERGIA"),
    PALADIN("Paladín", 2, 1, 2, 0, 3, 2, "MANA"),
    ROGUE("Ladrón", -1, 3, 0, 2, 1, 2, "ENERGIA"),
    BARD("Bardo", 0, 2, 1, 2, 1, 3, "MANA"),
    BARBARIAN("Bárbaro", 4, 0, 3, -1, 0, -2, "ENERGIA");

    public final String displayName;
    public final int bStr, bDex, bCon, bInt, bWis, bCha;
    public final String resourceType; // "MANA" o "ENERGIA"

    ClassType(String displayName, int bStr, int bDex, int bCon, int bInt, int bWis, int bCha, String resourceType) {
        this.displayName = displayName;
        this.bStr = bStr;
        this.bDex = bDex;
        this.bCon = bCon;
        this.bInt = bInt;
        this.bWis = bWis;
        this.bCha = bCha;
        this.resourceType = resourceType;
    }
}