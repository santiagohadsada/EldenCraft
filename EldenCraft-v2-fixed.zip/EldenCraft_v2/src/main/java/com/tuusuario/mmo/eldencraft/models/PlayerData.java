package com.tuusuario.mmo.eldencraft.models;

import com.tuusuario.mmo.eldencraft.missions.MissionProgress;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class PlayerData {
    private final UUID uuid;
    private RaceType race;
    private ClassType playerClass;
    private int level = 1;
    private int xp = 0;
    private double currentResource;
    private int fatigue = 0;

    // economia
    private int gold = 0;

    // misiones
    private final Map<String, MissionProgress> activeMissions = new HashMap<>();
    private final Set<String> completedMissions = new HashSet<>();

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.currentResource = 100.0;
    }

    // atributos finales (raza + clase)
    public int getStrength()     { return (race != null ? race.str   : 10) + (playerClass != null ? playerClass.bStr : 0); }
    public int getDexterity()    { return (race != null ? race.dex   : 10) + (playerClass != null ? playerClass.bDex : 0); }
    public int getConstitution() { return (race != null ? race.con   : 10) + (playerClass != null ? playerClass.bCon : 0); }
    public int getIntelligence() { return (race != null ? race.intel : 10) + (playerClass != null ? playerClass.bInt : 0); }
    public int getWisdom()       { return (race != null ? race.wis   : 10) + (playerClass != null ? playerClass.bWis : 0); }
    public int getCharisma()     { return (race != null ? race.cha   : 10) + (playerClass != null ? playerClass.bCha : 0); }

    // salud max
    public double getMaxHealth() {
        if (race == null) return 20.0;
        int totalCon = getConstitution();
        return race.baseHealth + ((totalCon - 10) * 1.0) + (level - 1) * 1.0;
    }

    // recurso (mana / energia)
    public double getMaxResource() {
        if (playerClass == null) return 100.0;
        // Magicos escalan con INT, fisicos con CON+DEX
        if ("MANA".equals(playerClass.resourceType)) {
            return 100.0 + (getIntelligence() * 5.0);
        } else {
            return 100.0 + (getConstitution() * 3.0) + (getDexterity() * 2.0);
        }
    }

    public double getCurrentResource() { return currentResource; }

    public void setCurrentResource(double val) {
        this.currentResource = Math.max(0, Math.min(val, getMaxResource()));
    }

    // getters / setters basicos
    public UUID getUuid() { return uuid; }
    public RaceType getRace() { return race; }
    public void setRace(RaceType race) {
        this.race = race;
        this.currentResource = getMaxResource();
    }
    public ClassType getPlayerClass() { return playerClass; }
    public void setPlayerClass(ClassType playerClass) {
        this.playerClass = playerClass;
        this.currentResource = getMaxResource();
    }
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = Math.max(1, Math.min(level, 20)); }
    public int getXp() { return xp; }
    public int getExp() { return xp; }
    public void setXp(int xp) { this.xp = Math.max(0, xp); }
    public int getFatigue() { return fatigue; }
    public void setFatigue(int fatigue) { this.fatigue = Math.max(0, Math.min(fatigue, 100)); }

    public int getGold() { return gold; }
    public void setGold(int gold) { this.gold = Math.max(0, gold); }

    public Map<String, MissionProgress> getActiveMissions() { return activeMissions; }
    public Set<String> getCompletedMissions() { return completedMissions; }
}
