package com.tuusuario.mmo.eldencraft;

import com.tuusuario.mmo.eldencraft.armor.armor.ArmorManager;
import com.tuusuario.mmo.eldencraft.armor.classes.ClassManager;
import com.tuusuario.mmo.eldencraft.armor.classes.EldenCraftClassManagerAdapter;
import com.tuusuario.mmo.eldencraft.armor.command.RpgArmorCommand;
import com.tuusuario.mmo.eldencraft.armor.config.ArmorConfig;
import com.tuusuario.mmo.eldencraft.armor.drops.DropManager;
import com.tuusuario.mmo.eldencraft.armor.listeners.AnvilListener;
import com.tuusuario.mmo.eldencraft.armor.listeners.ArmorListener;
import com.tuusuario.mmo.eldencraft.armor.listeners.MobDeathListener;
import com.tuusuario.mmo.eldencraft.armor.stats.StatManager;
import com.tuusuario.mmo.eldencraft.armor.upgrade.UpgradeManager;
import com.tuusuario.mmo.eldencraft.commands.AdminCommand;
import com.tuusuario.mmo.eldencraft.commands.BalanceCommand;
import com.tuusuario.mmo.eldencraft.commands.BossCommand;
import com.tuusuario.mmo.eldencraft.commands.MMOCommand;
import com.tuusuario.mmo.eldencraft.commands.MissionCommand;
import com.tuusuario.mmo.eldencraft.commands.PartyCommand;
import com.tuusuario.mmo.eldencraft.commands.ShopCommand;
import com.tuusuario.mmo.eldencraft.commands.SkillsCommand;
import com.tuusuario.mmo.eldencraft.listeners.*;
import com.tuusuario.mmo.eldencraft.listeners.MobDifficultyListener;
import com.tuusuario.mmo.eldencraft.managers.BossManager;
import com.tuusuario.mmo.eldencraft.managers.DataManager;
import com.tuusuario.mmo.eldencraft.managers.EconomyManager;
import com.tuusuario.mmo.eldencraft.managers.ExperienceManager;
import com.tuusuario.mmo.eldencraft.managers.MissionManager;
import com.tuusuario.mmo.eldencraft.managers.PartyManager;
import com.tuusuario.mmo.eldencraft.managers.RewardManager;
import com.tuusuario.mmo.eldencraft.managers.ShopManager;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import com.tuusuario.mmo.eldencraft.models.PlayerManager;
import com.tuusuario.mmo.eldencraft.recipes.StarterRecipes;
import com.tuusuario.mmo.eldencraft.skills.SkillManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class EldenCraft extends JavaPlugin {

    // Managers MMO base
    private PlayerManager      playerManager;
    private SkillManager       skillManager;
    private ExperienceManager  experienceManager;
    private EconomyManager     economyManager;
    private DataManager        dataManager;
    private MissionManager     missionManager;
    private ShopManager        shopManager;
    private RewardManager      rewardManager;
    private BossManager        bossManager;
    private PartyManager       partyManager;

    // Modulo de armaduras RPG
    private ArmorConfig    armorConfig;
    private ClassManager   armorClassManager;
    private StatManager    armorStatManager;
    private ArmorManager   armorManager;
    private UpgradeManager armorUpgradeManager;
    private DropManager    armorDropManager;

    // Listeners de los que necesitamos referencia
    private AbilityListener abilityListener;

    // Recetas iniciales por clase
    private StarterRecipes starterRecipes;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        // Managers, en orden de dependencia
        economyManager   = new EconomyManager(this);
        dataManager      = new DataManager(this);
        playerManager    = new PlayerManager(this);
        skillManager     = new SkillManager();
        rewardManager    = new RewardManager(this);
        experienceManager= new ExperienceManager(this);
        missionManager   = new MissionManager(this);
        shopManager      = new ShopManager(this);
        bossManager      = new BossManager(this);
        partyManager     = new PartyManager(this);

        // Modulo de armaduras
        armorConfig         = new ArmorConfig(this);
        armorConfig.reload();
        armorClassManager   = new EldenCraftClassManagerAdapter(this);
        armorStatManager    = new StatManager(this);
        armorManager        = new ArmorManager(this);
        armorUpgradeManager = new UpgradeManager(this);
        armorDropManager    = new DropManager(this);

        // Recetas iniciales (necesita armorManager listo)
        starterRecipes = new StarterRecipes(this);
        starterRecipes.register();

        // Listeners
        abilityListener = new AbilityListener(this);
        var pm = getServer().getPluginManager();
        pm.registerEvents(new SelectionGUI(this), this);
        pm.registerEvents(new ClassSelectionGUI(this), this);
        pm.registerEvents(abilityListener, this);
        pm.registerEvents(new SpellListener(this), this);
        pm.registerEvents(new PlayerListener(this), this);
        pm.registerEvents(new CombatListener(this), this);
        pm.registerEvents(new ExperienceListener(this), this);
        pm.registerEvents(new MissionProgressListener(this), this);
        pm.registerEvents(new MissionGUI(this), this);
        pm.registerEvents(new ShopGUI(this), this);
        pm.registerEvents(new BossListener(this), this);
        pm.registerEvents(new BlockSafetyListener(), this);
        pm.registerEvents(new MobDifficultyListener(this), this); // Escalado dinámico de dificultad
        pm.registerEvents(new SkillsGUI(this), this);
        // Armadura
        pm.registerEvents(new ArmorListener(this), this);
        pm.registerEvents(new AnvilListener(this), this);
        pm.registerEvents(new MobDeathListener(this), this);
        // Recetas iniciales
        pm.registerEvents(starterRecipes, this);

        // Comandos
        bind("mmo",        new MMOCommand(this));
        bind("shop",       new ShopCommand(this));
        bind("missions",   new MissionCommand(this));
        bind("balance",    new BalanceCommand(this));
        bind("eldencraft", new AdminCommand(this));
        bind("boss",       new BossCommand(this));
        bind("skills",     new SkillsCommand(this));
        bind("party",      new PartyCommand(this));
        bind("rpgarmor",   new RpgArmorCommand(this));

        // Cargar a los que ya estaban online (caso /reload)
        for (Player p : Bukkit.getOnlinePlayers()) {
            playerManager.loadPlayer(p.getUniqueId());
        }

        // Tarea principal del HUD: 1 vez por segundo
        Bukkit.getScheduler().runTaskTimer(this, this::tickHud, 0L, 20L);

        // Tick pasivo del modulo de armaduras (regen, etc.)
        armorStatManager.startPassiveTask();

        // Auto-save cada 5 minutos
        Bukkit.getScheduler().runTaskTimer(this, () -> playerManager.saveAll(), 6000L, 6000L);

        consoleBanner();
    }

    @Override
    public void onDisable() {
        if (armorStatManager != null) armorStatManager.shutdown();
        if (playerManager != null)    playerManager.saveAll();
        Bukkit.getConsoleSender().sendMessage(ChatColor.RED
                + "[EldenCraft] Plugin desactivado. Datos guardados.");
    }

    // /ec reload
    public void reloadAll() {
        reloadConfig();
        // Recargamos lo que se lee de disco
        missionManager = new MissionManager(this);
        shopManager    = new ShopManager(this);
        if (bossManager  != null) bossManager.loadBosses();
        if (armorConfig  != null) armorConfig.reload();
        // Las recetas se quedan donde estan, no haria falta volver a registrarlas
    }

    // helpers internos
    private void bind(String cmd, org.bukkit.command.CommandExecutor exec) {
        var c = getCommand(cmd);
        if (c != null) c.setExecutor(exec);
    }

    private void tickHud() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerData data = playerManager.getPlayerData(player.getUniqueId());
            if (data == null) continue;

            // Regen recurso (mana/energia) en funcion de Inteligencia
            double regen = data.getIntelligence() / 4.0;
            data.setCurrentResource(Math.min(data.getMaxResource(), data.getCurrentResource() + regen));

            // Decae fatiga
            if (data.getFatigue() > 0) {
                data.setFatigue(Math.max(0, data.getFatigue() - 2));
            }
            if (data.getFatigue() >= 100) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 40, 0));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1));
                player.damage(0.1);
            }

            // Si el menu de habilidades esta abierto NO sobrescribimos la action bar
            if (abilityListener != null && abilityListener.isMenuOpen(player.getUniqueId())) {
                continue;
            }

            String tipoRecurso = "Mana";
            ChatColor colorRecurso = ChatColor.AQUA;
            if (data.getPlayerClass() != null) {
                String c = data.getPlayerClass().name();
                if (c.equals("WARRIOR") || c.equals("BARBARIAN")
                 || c.equals("ROGUE")   || c.equals("RANGER")) {
                    tipoRecurso = "Energia";
                    colorRecurso = ChatColor.GOLD;
                }
            }
            int expReq = experienceManager.getRequiredExp(data.getLevel());
            String mensaje = ChatColor.GREEN + "Niv: " + data.getLevel() + " "
                    + colorRecurso + tipoRecurso + ": " + (int) data.getCurrentResource() + " "
                    + ChatColor.WHITE + "EXP: " + data.getXp() + "/" + expReq + " "
                    + ChatColor.YELLOW + "Fat: " + data.getFatigue() + "% "
                    + ChatColor.GOLD + "\u2666 " + data.getGold();
            player.sendActionBar(mensaje);
        }
    }

    private void consoleBanner() {
        var con = Bukkit.getConsoleSender();
        con.sendMessage(ChatColor.GOLD + "========================================");
        con.sendMessage(ChatColor.YELLOW + "EldenCraft MMO: v2.4 (Armor RPG + Recetas iniciales)");
        con.sendMessage(ChatColor.YELLOW + "  - Razas, Clases, Habilidades");
        con.sendMessage(ChatColor.YELLOW + "  - 50 Misiones cargadas");
        con.sendMessage(ChatColor.YELLOW + "  - Economia + Tienda por clase");
        con.sendMessage(ChatColor.YELLOW + "  - Sistema de Party + EXP compartida");
        con.sendMessage(ChatColor.YELLOW + "  - Armaduras RPG con clases, mejoras y drops");
        con.sendMessage(ChatColor.YELLOW + "  - Recetas iniciales por clase");
        con.sendMessage(ChatColor.YELLOW + "Autor: NaNO3");
        con.sendMessage(ChatColor.GOLD + "========================================");
    }

    // getters mmo base
    public PlayerManager     getPlayerManager()     { return playerManager; }
    public SkillManager      getSkillManager()      { return skillManager; }
    public ExperienceManager getExperienceManager() { return experienceManager; }
    public EconomyManager    getEconomyManager()    { return economyManager; }
    public DataManager       getDataManager()       { return dataManager; }
    public MissionManager    getMissionManager()    { return missionManager; }
    public ShopManager       getShopManager()       { return shopManager; }
    public RewardManager     getRewardManager()     { return rewardManager; }
    public BossManager       getBossManager()       { return bossManager; }
    public PartyManager      getPartyManager()      { return partyManager; }
    public AbilityListener   getAbilityListener()   { return abilityListener; }
    public StarterRecipes    getStarterRecipes()    { return starterRecipes; }

    // getters modulo armor
    public ArmorConfig    armorConfig()    { return armorConfig; }
    public ClassManager   classManager()   { return armorClassManager; }
    public StatManager    statManager()    { return armorStatManager; }
    public ArmorManager   armorManager()   { return armorManager; }
    public UpgradeManager upgradeManager() { return armorUpgradeManager; }
    public DropManager    dropManager()    { return armorDropManager; }
}
