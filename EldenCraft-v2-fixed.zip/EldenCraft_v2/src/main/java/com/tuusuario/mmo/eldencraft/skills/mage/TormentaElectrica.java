package com.tuusuario.mmo.eldencraft.skills.mage;

import com.tuusuario.mmo.eldencraft.skills.Skill;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.Sound;

public class TormentaElectrica implements Skill {
    public String getName() { return "Tormenta Eléctrica"; }
    public double getCost() { return 70.0; }
    public int getLevelRequired() { return 20; }

    public void execute(Player player, PlayerData data) {
        double dmg = 20.0 + (data.getIntelligence() * 0.8);
        player.getNearbyEntities(10, 10, 10).forEach(e -> {
            if (e instanceof LivingEntity && e != player) {
                LivingEntity target = (LivingEntity) e;
                // Usar player como fuente del daño para que:
                // 1) El friendly fire de party lo cancele si es un aliado
                // 2) El Contraataque del guerrero pueda reflejar el daño
                player.getWorld().strikeLightningEffect(e.getLocation());
                target.damage(dmg, player);
            }
        });
        player.playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1f);
    }
}
