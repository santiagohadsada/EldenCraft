package com.tuusuario.mmo.eldencraft.skills.bard;

import com.tuusuario.mmo.eldencraft.skills.Skill;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.Sound;

public class Inspiracion implements Skill {
    @Override
    public String getName() { return "Inspiración"; }
    @Override
    public double getCost() { return 60.0; }
    @Override
    public int getLevelRequired() { return 20; }

    @Override
    public void execute(Player player, PlayerData data) {
        player.getNearbyEntities(10, 10, 10).forEach(e -> {
            if (e instanceof Player ally) {
                ally.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 300, 1));
                ally.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 300, 1));
                ally.sendMessage("§d§l» §f¡Te sientes inspirado por la música!");
            }
        });
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1.5f);
    }
}