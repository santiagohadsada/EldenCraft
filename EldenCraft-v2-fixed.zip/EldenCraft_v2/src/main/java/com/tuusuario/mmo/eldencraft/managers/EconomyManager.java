package com.tuusuario.mmo.eldencraft.managers;

import com.tuusuario.mmo.eldencraft.EldenCraft;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

// Maneja la economia del MMO (oro propio, NO Vault).
public class EconomyManager {

    private final EldenCraft plugin;

    public EconomyManager(EldenCraft plugin) {
        this.plugin = plugin;
    }

    // Saldo actual.
    public int getGold(PlayerData data) {
        return data.getGold();
    }

    // Anade oro al jugador.
    public void addGold(PlayerData data, int amount) {
        if (amount <= 0) return;
        data.setGold(data.getGold() + amount);
    }

    // Intenta cobrar oro.
    public boolean removeGold(PlayerData data, int amount) {
        if (data.getGold() < amount) return false;
        data.setGold(data.getGold() - amount);
        return true;
    }

    // Setea el oro a un valor concreto (admin).
    public void setGold(PlayerData data, int amount) {
        data.setGold(Math.max(0, amount));
    }

    // Mensaje "you got X gold" estandar.
    public void notifyGold(Player player, int amount) {
        player.sendMessage(ChatColor.GOLD + "✦ +" + amount + " oro");
    }

    // Lee el multiplicador de drop de oro de mobs hostiles desde config.
    public double getHostileDropMultiplier() {
        return plugin.getConfig().getDouble("economy.hostile-mob-drop-multiplier", 0.5);
    }

    // Oro inicial al crear personaje.
    public int getStartingGold() {
        return plugin.getConfig().getInt("economy.starting-gold", 50);
    }

    // Oro extra por subir de nivel.
    public int getGoldPerLevel() {
        return plugin.getConfig().getInt("economy.gold-per-level", 100);
    }
}
