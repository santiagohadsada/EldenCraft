package com.tuusuario.mmo.eldencraft.managers;

import com.tuusuario.mmo.eldencraft.EldenCraft;
import com.tuusuario.mmo.eldencraft.missions.MissionProgress;
import com.tuusuario.mmo.eldencraft.models.ClassType;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import com.tuusuario.mmo.eldencraft.models.RaceType;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

// Persistencia de PlayerData en archivos YAML dentro de plugins/EldenCraft/players/<uuid>.yml
public class DataManager {

    private final EldenCraft plugin;
    private final File playersDir;

    public DataManager(EldenCraft plugin) {
        this.plugin = plugin;
        this.playersDir = new File(plugin.getDataFolder(), "players");
        if (!playersDir.exists()) playersDir.mkdirs();
    }

    private File fileFor(UUID uuid) {
        return new File(playersDir, uuid.toString() + ".yml");
    }

    // Carga (o crea vacio) el PlayerData del jugador.
    public PlayerData load(UUID uuid) {
        PlayerData data = new PlayerData(uuid);
        File f = fileFor(uuid);
        if (!f.exists()) {
            data.setGold(plugin.getEconomyManager().getStartingGold());
            return data;
        }
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        try {
            String race = cfg.getString("race");
            if (race != null) data.setRace(RaceType.valueOf(race));

            String clazz = cfg.getString("class");
            if (clazz != null) data.setPlayerClass(ClassType.valueOf(clazz));

            data.setLevel(cfg.getInt("level", 1));
            data.setXp(cfg.getInt("xp", 0));
            data.setGold(cfg.getInt("gold", plugin.getEconomyManager().getStartingGold()));
            data.setFatigue(cfg.getInt("fatigue", 0));

            // Misiones completadas
            List<String> completed = cfg.getStringList("completedMissions");
            data.getCompletedMissions().addAll(completed);

            // Misiones activas
            ConfigurationSection actSec = cfg.getConfigurationSection("activeMissions");
            if (actSec != null) {
                for (String id : actSec.getKeys(false)) {
                    int prog = actSec.getInt(id, 0);
                    data.getActiveMissions().put(id, new MissionProgress(id, prog));
                }
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Error cargando datos de " + uuid + ": " + e.getMessage());
        }
        return data;
    }

    // Guarda el PlayerData en disco.
    public void save(PlayerData data) {
        if (data == null) return;
        File f = fileFor(data.getUuid());
        FileConfiguration cfg = new YamlConfiguration();

        if (data.getRace() != null) cfg.set("race", data.getRace().name());
        if (data.getPlayerClass() != null) cfg.set("class", data.getPlayerClass().name());
        cfg.set("level", data.getLevel());
        cfg.set("xp", data.getXp());
        cfg.set("gold", data.getGold());
        cfg.set("fatigue", data.getFatigue());

        cfg.set("completedMissions", new ArrayList<>(data.getCompletedMissions()));
        for (MissionProgress mp : data.getActiveMissions().values()) {
            cfg.set("activeMissions." + mp.getMissionId(), mp.getProgress());
        }

        try {
            cfg.save(f);
        } catch (IOException e) {
            plugin.getLogger().warning("Error guardando datos de " + data.getUuid() + ": " + e.getMessage());
        }
    }

    // Borra los datos de un jugador (admin).
    public void delete(UUID uuid) {
        File f = fileFor(uuid);
        if (f.exists()) f.delete();
    }
}
