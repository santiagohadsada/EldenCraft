package com.tuusuario.mmo.eldencraft.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

// Estado compartido en memoria para los efectos de balance/clase (Bárbaro berserk, Guerrero parry/lifesteal, Paladín tótem, Pícaro crítico).
public final class BalanceState {

    private BalanceState() {}

    // Bárbaro – Furia Extrema activa: recibe x2 de daño mientras dura
    public static final Set<UUID> barbarianBerserk =
            Collections.synchronizedSet(new HashSet<>());

    // Guerrero – Postura de Combate activa: lifesteal por golpe
    public static final Set<UUID> warriorLifesteal =
            Collections.synchronizedSet(new HashSet<>());

    // Guerrero – Contraataque activo: refleja 50% del daño recibido
    public static final Set<UUID> warriorParry =
            Collections.synchronizedSet(new HashSet<>());

    // Paladín – Tótem Divino activo: UUID -> timestamp de expiración (ms)
    public static final Map<UUID, Long> paladinTotem =
            Collections.synchronizedMap(new HashMap<>());

    // Pícaro – siguiente golpe melee multiplicador (2.0 = crítico, 4.0 = doble crítico)
    public static final Map<UUID, Double> rogueCritNext =
            Collections.synchronizedMap(new HashMap<>());

    public static boolean isBerserk(UUID id) { return barbarianBerserk.contains(id); }
    public static boolean hasLifesteal(UUID id) { return warriorLifesteal.contains(id); }
    public static boolean isParrying(UUID id) { return warriorParry.contains(id); }

    public static boolean hasActiveTotem(UUID id) {
        Long exp = paladinTotem.get(id);
        if (exp == null) return false;
        if (System.currentTimeMillis() > exp) {
            paladinTotem.remove(id);
            return false;
        }
        return true;
    }
}
