package com.tuusuario.mmo.eldencraft.managers;

import com.tuusuario.mmo.eldencraft.EldenCraft;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

// Tabla de EXP por mob (TODOS los mobs hostiles, neutrales y pasivos).
public class ExperienceManager {

    private final EldenCraft plugin;
    private final Map<EntityType, Integer> mobExpMap = new HashMap<>();

    public ExperienceManager(EldenCraft plugin) {
        this.plugin = plugin;
        setupMobExp();
    }

    private void setupMobExp() {
        // hostiles basicos
        put("ZOMBIE", 6);
        put("ZOMBIE_VILLAGER", 8);
        put("HUSK", 7);
        put("DROWNED", 8);
        put("SKELETON", 7);
        put("STRAY", 9);
        put("BOGGED", 9);          // 1.21+
        put("WITHER_SKELETON", 25);
        put("CREEPER", 10);
        put("SPIDER", 5);
        put("CAVE_SPIDER", 6);
        put("ENDERMAN", 18);
        put("ENDERMITE", 6);
        put("SILVERFISH", 4);
        put("SLIME", 4);
        put("MAGMA_CUBE", 5);
        put("BLAZE", 18);
        put("GHAST", 25);
        put("WITCH", 16);
        put("PHANTOM", 14);
        put("VEX", 10);
        put("PILLAGER", 12);
        put("VINDICATOR", 18);
        put("EVOKER", 30);
        put("ILLUSIONER", 30);
        put("RAVAGER", 50);
        put("HOGLIN", 14);
        put("ZOGLIN", 16);
        put("PIGLIN", 8);
        put("PIGLIN_BRUTE", 22);
        put("ZOMBIFIED_PIGLIN", 6);
        put("WARDEN", 200);
        put("BREEZE", 25);          // 1.21+
        put("GUARDIAN", 14);
        put("ELDER_GUARDIAN", 100);
        put("SHULKER", 25);

        // neutrales
        put("WOLF", 4);
        put("POLAR_BEAR", 6);
        put("LLAMA", 3);
        put("TRADER_LLAMA", 3);
        put("PANDA", 3);
        put("BEE", 2);
        put("DOLPHIN", 3);
        put("FOX", 3);
        put("GOAT", 3);
        put("IRON_GOLEM", 12);
        put("SNOW_GOLEM", 4);

        // pasivos (poca exp)
        put("COW", 1);
        put("PIG", 1);
        put("CHICKEN", 1);
        put("SHEEP", 1);
        put("HORSE", 2);
        put("DONKEY", 2);
        put("MULE", 2);
        put("RABBIT", 1);
        put("MOOSHROOM", 2);
        put("CAT", 1);
        put("OCELOT", 2);
        put("PARROT", 1);
        put("VILLAGER", 1);
        put("WANDERING_TRADER", 2);
        put("AXOLOTL", 1);
        put("FROG", 1);
        put("CAMEL", 2);            // 1.20
        put("SNIFFER", 2);          // 1.20
        put("ALLAY", 1);
        put("ARMADILLO", 2);        // 1.21+
        put("GLOW_SQUID", 1);
        put("SQUID", 1);
        put("BAT", 1);
        put("COD", 1);
        put("SALMON", 1);
        put("PUFFERFISH", 1);
        put("TROPICAL_FISH", 1);
        put("TADPOLE", 1);
        put("STRIDER", 2);
        put("TURTLE", 2);

        // bosses
        put("WITHER", 800);
        put("ENDER_DRAGON", 1200);
    }

    // Helper que ignora EntityType desconocidos en otra version (ej.
    private void put(String entityName, int exp) {
        try {
            EntityType t = EntityType.valueOf(entityName);
            mobExpMap.put(t, exp);
        } catch (IllegalArgumentException ignored) {
            // El entityType no existe en esta version, lo saltamos en silencio
        }
    }

    // Obtiene la EXP base por matar un mob.
    public int getExpFromMob(EntityType type) {
        int base = mobExpMap.getOrDefault(type, 3);
        double mul = plugin.getConfig().getDouble("experience.mob-exp-multiplier", 1.0);
        return Math.max(1, (int) (base * mul));
    }

    // Formula de EXP requerida por nivel.
    public int getRequiredExp(int level) {
        return (int) (150 * Math.pow(1.45, level - 1));
    }

    // Comprueba subida de nivel y aplica recompensas.
    public void checkLevelUp(Player player, PlayerData data) {
        boolean leveled = false;
        while (data.getLevel() < 20) {
            int req = getRequiredExp(data.getLevel());
            if (data.getXp() >= req) {
                data.setXp(data.getXp() - req);
                data.setLevel(data.getLevel() + 1);
                onLevelUp(player, data);
                leveled = true;
            } else break;
        }
        if (data.getLevel() >= 20) data.setXp(0);

        if (leveled) {
            // Refrescar vida maxima (API de atributos en 1.21)
            applyMaxHealth(player, data);
        }
    }

    // Aplica la vida maxima del PlayerData al jugador usando la API de atributos (compatible con 1.20+ y 1.21+; setMaxHealth ya no existe en 1.21).
    public static void applyMaxHealth(Player player, PlayerData data) {
        try {
            var attr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
            if (attr != null) {
                attr.setBaseValue(data.getMaxHealth());
                if (player.getHealth() > data.getMaxHealth()) {
                    player.setHealth(data.getMaxHealth());
                }
            }
        } catch (Throwable ignored) { }
    }

    private void onLevelUp(Player player, PlayerData data) {
        int nuevo = data.getLevel();
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        player.sendMessage("");
        player.sendMessage(ChatColor.GOLD + "★★★ " + ChatColor.YELLOW + ChatColor.BOLD
                + "¡SUBISTE AL NIVEL " + nuevo + "!" + ChatColor.GOLD + " ★★★");

        int[] hitos = {1, 3, 6, 9, 12, 16, 20};
        for (int h : hitos) {
            if (nuevo == h) {
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
                player.sendMessage(ChatColor.AQUA + "✦ ¡Nueva habilidad desbloqueada! "
                        + ChatColor.WHITE + "Pulsa [F] para verla.");
                break;
            }
        }

        // Recompensa de oro fija
        int gold = plugin.getEconomyManager().getGoldPerLevel();
        if (gold > 0) {
            plugin.getEconomyManager().addGold(data, gold);
            player.sendMessage(ChatColor.GOLD + "+ " + gold + " oro");
        }

        // Recompensas configurables del nivel (oro extra + items)
        plugin.getRewardManager().giveLevelReward(player, data, nuevo);
        player.sendMessage("");
    }
}
