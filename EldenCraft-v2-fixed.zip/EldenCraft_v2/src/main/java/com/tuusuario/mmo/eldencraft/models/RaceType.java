package com.tuusuario.mmo.eldencraft.models;
// Define las razas del juego y sus estadísticas base.
public enum RaceType {
    // Definición de las constantes (Instancias del Enum)
    // Nombre, STR, DEX, CON, INT, WIS, CHA, SaludBase (20.0 = 10 corazones)
    HUMAN("Humano", 10, 10, 10, 10, 10, 10, 20.0),
    DWARF("Enano", 12, 8, 14, 10, 12, 8, 24.0),
    ELF("Elfo", 8, 14, 10, 12, 10, 10, 16.0),
    HOBBIT("Hobbit", 6, 10, 12, 8, 10, 8, 12.0),
    ORC("Orco", 16, 10, 14, 8, 8, 6, 28.0),
    GNOME("Gnomo", 8, 12, 10, 14, 10, 10, 16.0);

    // Atributos finales (Inmutables)
    public final String displayName;
    public final int str, dex, con, intel, wis, cha;
    public final double baseHealth;

    // Constructor del Enum (Siempre es privado internamente)
    RaceType(String displayName, int str, int dex, int con, int intel, int wis, int cha, double baseHealth) {
        this.displayName = displayName;
        this.str = str;
        this.dex = dex;
        this.con = con;
        this.intel = intel;
        this.wis = wis;
        this.cha = cha;
        this.baseHealth = baseHealth;
    }
}