package com.tuusuario.mmo.eldencraft.listeners;

import org.bukkit.entity.DragonFireball;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.LargeFireball;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.SmallFireball;
import org.bukkit.entity.WitherSkull;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.projectiles.ProjectileSource;

// Garantiza que ninguna habilidad del plugin destruya bloques o provoque incendios.
public class BlockSafetyListener implements Listener {

    @EventHandler
    public void onExplode(EntityExplodeEvent event) {
        Entity ent = event.getEntity();
        if (isPlayerLaunchedFireball(ent)) {
            // Cancela la rotura de bloques pero deja el daño a entidades.
            event.blockList().clear();
        }
    }

    @EventHandler
    public void onIgnite(BlockIgniteEvent event) {
        // Cualquier ignicion causada por una bola de fuego o por un jugador
        // a traves de un proyectil del plugin se cancela.
        if (event.getCause() == BlockIgniteEvent.IgniteCause.FIREBALL) {
            Entity igniting = event.getIgnitingEntity();
            if (igniting == null || isPlayerLaunchedFireball(igniting)) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onEntityChangeBlock(EntityChangeBlockEvent event) {
        // Evita que un proyectil del jugador cambie/rompa un bloque
        // (ej. apagar antorchas, romper cultivos, etc).
        if (isPlayerLaunchedFireball(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    private boolean isPlayerLaunchedFireball(Entity ent) {
        if (!(ent instanceof Fireball || ent instanceof SmallFireball
            || ent instanceof LargeFireball || ent instanceof DragonFireball
            || ent instanceof WitherSkull)) {
            return false;
        }
        if (ent instanceof Projectile proj) {
            ProjectileSource src = proj.getShooter();
            return src instanceof Player;
        }
        return false;
    }
}
