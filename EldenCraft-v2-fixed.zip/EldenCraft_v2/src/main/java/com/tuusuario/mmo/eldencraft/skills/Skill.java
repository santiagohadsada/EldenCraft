package com.tuusuario.mmo.eldencraft.skills;

import com.tuusuario.mmo.eldencraft.models.PlayerData;
import com.tuusuario.mmo.eldencraft.util.SkillDescriptions;
import org.bukkit.entity.Player;

public interface Skill {
    String getName();            // Nombre de la habilidad
    double getCost();            // Coste de Maná o Energía
    int getLevelRequired();      // Nivel para desbloquear (1, 3, 6, 9, 12, 16, 20)
    void execute(Player player, PlayerData data); // Lo que hace la habilidad

    // Descripcion humana de la habilidad para el menu /skills.
    default String getDescription() {
        return SkillDescriptions.get(this);
    }
}
