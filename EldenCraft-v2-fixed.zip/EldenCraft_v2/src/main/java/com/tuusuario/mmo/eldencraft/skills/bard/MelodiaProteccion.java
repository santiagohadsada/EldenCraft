package com.tuusuario.mmo.eldencraft.skills.bard;

import com.tuusuario.mmo.eldencraft.skills.Skill;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.Sound;

public class MelodiaProteccion implements Skill {
    @Override
    public String getName() { return "Melodía de Protección"; }
    @Override
    public double getCost() { return 25.0; }
    @Override
    public int getLevelRequired() { return 3; }

    @Override
    public void execute(Player player, PlayerData data) {
        int power = Math.max(0, data.getCharisma() / 15);
        player.getNearbyEntities(8, 8, 8).forEach(e -> {
            if (e instanceof Player ally) {
                ally.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, power));
            }
        });
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_GUITAR, 1f, 0.8f);
    }
}