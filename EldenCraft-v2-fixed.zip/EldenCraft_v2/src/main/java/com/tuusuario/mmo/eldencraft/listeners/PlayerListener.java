package com.tuusuario.mmo.eldencraft.listeners;

import com.tuusuario.mmo.eldencraft.EldenCraft;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerListener implements Listener {

    private final EldenCraft plugin;

    public PlayerListener(EldenCraft plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        // Carga (o crea) la ficha desde disco
        PlayerData data = plugin.getPlayerManager().loadPlayer(player.getUniqueId());

        // Aplica vida maxima si ya tenia raza/clase
        if (data.getRace() != null) {
            com.tuusuario.mmo.eldencraft.managers.ExperienceManager.applyMaxHealth(player, data);
        }

        player.sendMessage(ChatColor.GREEN + "¡Bienvenido a EldenCraft, " + player.getName() + "!");

        // Si el jugador es nuevo, abrir menu de seleccion
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (data.getRace() == null) {
                new SelectionGUI(plugin).openRaceMenu(player);
                player.sendMessage(ChatColor.YELLOW + "" + ChatColor.BOLD
                        + "⚠ Debes elegir una raza para comenzar tu aventura.");
            } else {
                player.sendMessage(ChatColor.GRAY + "Eres un " + ChatColor.GOLD
                        + data.getRace().displayName + " "
                        + (data.getPlayerClass() != null ? data.getPlayerClass().displayName : "")
                        + ChatColor.GRAY + " (Niv " + data.getLevel() + ").");
            }
        }, 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Limpia party / invitaciones
        if (plugin.getPartyManager() != null) {
            plugin.getPartyManager().handleQuit(event.getPlayer().getUniqueId());
        }
        plugin.getPlayerManager().unloadPlayer(event.getPlayer().getUniqueId());
    }
}
