package com.tuusuario.mmo.eldencraft.managers;

import com.tuusuario.mmo.eldencraft.EldenCraft;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Gestor del sistema de jefes legendarios.
public class BossManager {

    private final EldenCraft plugin;
    private final Map<String, BossDef> bosses = new LinkedHashMap<>();

    // Clave de NBT para marcar entidades-jefe.
    public final NamespacedKey BOSS_KEY;

    public BossManager(EldenCraft plugin) {
        this.plugin = plugin;
        this.BOSS_KEY = new NamespacedKey(plugin, "boss_id");
        loadBosses();
    }

    // Recarga el archivo bosses.yml.
    public void loadBosses() {
        bosses.clear();

        File f = new File(plugin.getDataFolder(), "bosses.yml");
        if (!f.exists()) plugin.saveResource("bosses.yml", false);

        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);

        // Tambien fusionamos defaults del jar para que falten claves nunca rompan
        try (InputStreamReader r = new InputStreamReader(plugin.getResource("bosses.yml"))) {
            cfg.setDefaults(YamlConfiguration.loadConfiguration(r));
        } catch (Exception ignored) { }

        ConfigurationSection root = cfg.getConfigurationSection("bosses");
        if (root == null) return;

        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;

            BossDef b = new BossDef();
            b.id = id;
            b.entityName = s.getString("entity", "ZOMBIE");
            b.display = ChatColor.translateAlternateColorCodes('&', s.getString("display", id));
            b.maxHealth = s.getDouble("max-health", 200);
            b.damage = s.getDouble("damage", 8);
            b.armor = s.getDouble("armor", 6);
            b.speed = s.getDouble("speed", 1.0);
            b.glowing = s.getBoolean("glowing", true);
            b.expReward = s.getInt("exp-reward", 500);
            b.goldReward = s.getInt("gold-reward", 250);
            b.announce = ChatColor.translateAlternateColorCodes('&',
                    s.getString("announce", "&6Un jefe ha aparecido!"));

            for (String entry : s.getStringList("loot")) {
                String[] p = entry.split(":");
                if (p.length < 1) continue;
                try {
                    Material mat = Material.valueOf(p[0].trim().toUpperCase());
                    int qty = (p.length >= 2) ? Math.max(1, Integer.parseInt(p[1].trim())) : 1;
                    b.loot.add(new ItemStack(mat, qty));
                } catch (Exception ignored) { /* item desconocido en esta version */ }
            }

            bosses.put(id.toLowerCase(), b);
        }

        plugin.getLogger().info("Cargados " + bosses.size() + " jefes legendarios.");
    }

    public Map<String, BossDef> getBosses() { return bosses; }

    // Invoca un jefe en la posicion dada.
    public LivingEntity spawn(String bossId, Location loc) {
        BossDef def = bosses.get(bossId.toLowerCase());
        if (def == null || loc == null || loc.getWorld() == null) return null;

        EntityType type;
        try { type = EntityType.valueOf(def.entityName); }
        catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Boss '" + def.id + "' usa entityType desconocido en esta version: " + def.entityName);
            return null;
        }

        Entity e = loc.getWorld().spawnEntity(loc, type);
        if (!(e instanceof LivingEntity le)) {
            e.remove();
            return null;
        }

        // Marcar como jefe
        le.getPersistentDataContainer().set(BOSS_KEY, PersistentDataType.STRING, def.id);
        le.setCustomName(def.display);
        le.setCustomNameVisible(true);
        le.setRemoveWhenFarAway(false);
        le.setGlowing(def.glowing);

        // Atributos
        applyAttribute(le, Attribute.GENERIC_MAX_HEALTH, def.maxHealth);
        le.setHealth(Math.min(def.maxHealth, le.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue()));
        applyAttribute(le, Attribute.GENERIC_ATTACK_DAMAGE, def.damage);
        applyAttribute(le, Attribute.GENERIC_ARMOR, def.armor);
        applyAttribute(le, Attribute.GENERIC_MOVEMENT_SPEED, baseSpeed(le) * def.speed);

        // Anuncio global
        Bukkit.broadcastMessage("");
        Bukkit.broadcastMessage("§6§l☠ §e§lJEFE INVOCADO §6§l☠");
        Bukkit.broadcastMessage(def.announce);
        Bukkit.broadcastMessage("§7Coordenadas: §f" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ()
                + " §7(" + loc.getWorld().getName() + ")");
        Bukkit.broadcastMessage("");

        return le;
    }

    private void applyAttribute(LivingEntity e, Attribute a, double value) {
        try {
            var inst = e.getAttribute(a);
            if (inst != null) inst.setBaseValue(value);
        } catch (Throwable ignored) { }
    }

    private double baseSpeed(LivingEntity e) {
        try {
            var inst = e.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
            return inst != null ? inst.getBaseValue() : 0.25;
        } catch (Throwable ignored) { return 0.25; }
    }

    // Devuelve la def de un jefe por su ID guardado en NBT.
    public BossDef getBossOf(LivingEntity e) {
        String id = e.getPersistentDataContainer().get(BOSS_KEY, PersistentDataType.STRING);
        if (id == null) return null;
        return bosses.get(id.toLowerCase());
    }

    // Definicion en memoria de un jefe.
    public static class BossDef {
        public String id;
        public String entityName;
        public String display;
        public double maxHealth;
        public double damage;
        public double armor;
        public double speed;
        public boolean glowing;
        public int expReward;
        public int goldReward;
        public String announce;
        public List<ItemStack> loot = new ArrayList<>();
    }

    // Devuelve un Map id -> nombre amigable, util para listar.
    public Map<String, String> listIds() {
        Map<String, String> m = new HashMap<>();
        for (var e : bosses.entrySet()) m.put(e.getKey(), e.getValue().display);
        return m;
    }
}
