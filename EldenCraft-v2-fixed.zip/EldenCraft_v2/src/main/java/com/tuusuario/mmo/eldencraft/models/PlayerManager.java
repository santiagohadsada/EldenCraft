package com.tuusuario.mmo.eldencraft.models;

import com.tuusuario.mmo.eldencraft.EldenCraft;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

// Cache de PlayerData en RAM.
public class PlayerManager {

    private final EldenCraft plugin;
    private final Map<UUID, PlayerData> players = new HashMap<>();

    public PlayerManager(EldenCraft plugin) {
        this.plugin = plugin;
    }

    // Llamado en PlayerJoin: carga desde disco.
    public PlayerData loadPlayer(UUID uuid) {
        PlayerData data = plugin.getDataManager().load(uuid);
        players.put(uuid, data);
        return data;
    }

    // Llamado en PlayerQuit: guarda y libera.
    public void unloadPlayer(UUID uuid) {
        PlayerData data = players.remove(uuid);
        if (data != null) plugin.getDataManager().save(data);
    }

    // Guarda todo (al apagar o cada cierto tiempo).
    public void saveAll() {
        for (PlayerData d : players.values()) {
            plugin.getDataManager().save(d);
        }
    }

    public PlayerData getPlayerData(UUID uuid) {
        return players.get(uuid);
    }

    public Map<UUID, PlayerData> getAll() {
        return players;
    }
}
