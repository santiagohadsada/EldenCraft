package com.tuusuario.mmo.eldencraft.listeners;

import com.tuusuario.mmo.eldencraft.EldenCraft;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import com.tuusuario.mmo.eldencraft.skills.Skill;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

// Menu /skills: muestra las 7 habilidades del jugador con descripcion, coste, nivel necesario y estado (desbloqueada / bloqueada).
public class SkillsGUI implements Listener {

    public static final String TITLE = "§5§l✦ Habilidades §8(/skills)";

    private static final int[] SLOTS = {10, 11, 12, 13, 14, 15, 16};
    private static final int[] HITOS = {1, 3, 6, 9, 12, 16, 20};

    private final EldenCraft plugin;

    public SkillsGUI(EldenCraft plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, PlayerData data) {
        Inventory gui = Bukkit.createInventory(null, 27, TITLE);

        // Relleno gris de fondo
        ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta paneMeta = pane.getItemMeta();
        paneMeta.setDisplayName(" ");
        pane.setItemMeta(paneMeta);
        for (int i = 0; i < 27; i++) gui.setItem(i, pane);

        for (int i = 0; i < 7; i++) {
            int slotNum = i + 1;
            int hito = HITOS[i];
            Skill skill = plugin.getSkillManager().getSkill(data.getPlayerClass(), slotNum);

            ItemStack item;
            ItemMeta meta;
            List<String> lore = new ArrayList<>();

            if (skill == null) {
                item = new ItemStack(Material.STRUCTURE_VOID);
                meta = item.getItemMeta();
                meta.setDisplayName(ChatColor.DARK_GRAY + "Slot " + slotNum + " - Vacio");
                lore.add(ChatColor.GRAY + "Aun no hay habilidad asignada.");
            } else {
                boolean unlocked = data.getLevel() >= skill.getLevelRequired();
                item = new ItemStack(unlocked ? Material.ENCHANTED_BOOK : Material.BARRIER);
                meta = item.getItemMeta();
                String prefix = unlocked ? ChatColor.GREEN + "" + ChatColor.BOLD : ChatColor.DARK_RED + "";
                meta.setDisplayName(prefix + slotNum + ". " + skill.getName());

                lore.add(ChatColor.DARK_GRAY + "──────────────");
                lore.add(ChatColor.GRAY + skill.getDescription());
                lore.add(ChatColor.DARK_GRAY + "──────────────");
                lore.add(ChatColor.YELLOW + "Nivel requerido: " + ChatColor.WHITE + skill.getLevelRequired());
                lore.add(ChatColor.AQUA  + "Coste: "           + ChatColor.WHITE + (int) skill.getCost());
                lore.add(ChatColor.GOLD  + "Slot: "            + ChatColor.WHITE + "[" + slotNum + "]");
                lore.add("");
                if (unlocked) {
                    lore.add(ChatColor.GREEN + "✔ Desbloqueada");
                    lore.add(ChatColor.GRAY + "Pulsa F y la tecla "
                            + ChatColor.YELLOW + slotNum + ChatColor.GRAY + " en juego.");
                } else {
                    lore.add(ChatColor.RED + "✖ Bloqueada (Niv " + skill.getLevelRequired() + ")");
                }
            }
            meta.setLore(lore);
            item.setItemMeta(meta);
            gui.setItem(SLOTS[i], item);
        }

        // Item informativo en slot 4 (parte superior)
        ItemStack info = new ItemStack(Material.BOOK);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(ChatColor.GOLD + "Clase: " + data.getPlayerClass().displayName);
        List<String> ilore = new ArrayList<>();
        ilore.add(ChatColor.GRAY + "Nivel actual: " + ChatColor.WHITE + data.getLevel());
        ilore.add(ChatColor.GRAY + "Pulsa F en el juego para abrir el");
        ilore.add(ChatColor.GRAY + "menu rapido de habilidades.");
        im.setLore(ilore);
        info.setItemMeta(im);
        gui.setItem(4, info);

        player.openInventory(gui);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!TITLE.equals(e.getView().getTitle())) return;
        e.setCancelled(true);
    }
}
