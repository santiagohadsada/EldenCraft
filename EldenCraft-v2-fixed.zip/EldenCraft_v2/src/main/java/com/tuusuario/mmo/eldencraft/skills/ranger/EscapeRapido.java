package com.tuusuario.mmo.eldencraft.skills.ranger;

import com.tuusuario.mmo.eldencraft.skills.Skill;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

// Salto del Ciervo: gran salto vertical, velocidad alta y caída suave.
public class EscapeRapido implements Skill {

    @Override
    public String getName() { return "Salto del Ciervo"; }
    @Override
    public double getCost() { return 50.0; }
    @Override
    public int getLevelRequired() { return 20; }

    @Override
    public void execute(Player player, PlayerData data) {
        // Impulso vertical (escala suavemente con destreza)
        double impulso = 1.5 + Math.min(0.6, data.getDexterity() * 0.02);
        Vector v = player.getVelocity();
        v.setY(impulso);
        // Pequeño empujón hacia adelante para "saltar" en la dirección de la mirada
        Vector mirada = player.getLocation().getDirection().setY(0).normalize().multiply(0.7);
        v.add(mirada);
        player.setVelocity(v);

        // Buff de movilidad y caída segura
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 3));
        player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 200, 3));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 120, 0));
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));

        player.playSound(player.getLocation(), Sound.ENTITY_HORSE_JUMP, 1f, 1.5f);
        player.playSound(player.getLocation(), Sound.ITEM_ELYTRA_FLYING, 0.5f, 1.4f);
        player.getWorld().spawnParticle(Particle.CLOUD,
                player.getLocation(), 30, 0.4, 0.1, 0.4, 0.05);
        player.getWorld().spawnParticle(Particle.HAPPY_VILLAGER,
                player.getLocation().add(0, 1, 0), 12, 0.5, 0.5, 0.5, 0);
        player.sendMessage("§a[!] §7Saltas con la agilidad de un ciervo.");
    }
}
