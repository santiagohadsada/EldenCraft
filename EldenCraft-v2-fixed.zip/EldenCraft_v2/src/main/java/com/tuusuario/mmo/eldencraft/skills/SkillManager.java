package com.tuusuario.mmo.eldencraft.skills;

import com.tuusuario.mmo.eldencraft.models.ClassType;
import java.util.HashMap;
import java.util.Map;

// Imports por paquetes (El asterisco .* importa todas las clases de esa carpeta)
import com.tuusuario.mmo.eldencraft.skills.warrior.*;
import com.tuusuario.mmo.eldencraft.skills.mage.*;
import com.tuusuario.mmo.eldencraft.skills.ranger.*;
import com.tuusuario.mmo.eldencraft.skills.paladin.*;
import com.tuusuario.mmo.eldencraft.skills.rogue.*;
import com.tuusuario.mmo.eldencraft.skills.bard.*;
import com.tuusuario.mmo.eldencraft.skills.barbarian.*;

public class SkillManager {
    // Mapa que guarda: "CLASE_SLOT" -> Objeto de la Habilidad
    private final Map<String, Skill> skillRegistry = new HashMap<>();

    public SkillManager() {
        // registro de guerrero (warrior)
        register(ClassType.WARRIOR, 1, new GolpePoderoso());
        register(ClassType.WARRIOR, 2, new DefensaSolida());
        register(ClassType.WARRIOR, 3, new CargaFuriosa());
        register(ClassType.WARRIOR, 4, new EscudoProtector());
        register(ClassType.WARRIOR, 5, new FuriaGuerrera());
        register(ClassType.WARRIOR, 6, new SaltoCombate());
        register(ClassType.WARRIOR, 7, new RabiaCiega());

        // registro de mago (mage)
        register(ClassType.MAGE, 1, new BolaFuego());
        register(ClassType.MAGE, 2, new EscudoMagico());
        register(ClassType.MAGE, 3, new Teleportacion());
        register(ClassType.MAGE, 4, new LluviaHielo());
        register(ClassType.MAGE, 5, new ExplosionMagica());
        register(ClassType.MAGE, 6, new CuracionMagica());
        register(ClassType.MAGE, 7, new TormentaElectrica());

        // registro de explorador (ranger)
        register(ClassType.RANGER, 1, new Rastreo());
        register(ClassType.RANGER, 2, new FlechaPrecisa());
        register(ClassType.RANGER, 3, new Camuflaje());
        register(ClassType.RANGER, 4, new TrampaCaza());
        register(ClassType.RANGER, 5, new VisionNocturna());
        register(ClassType.RANGER, 6, new AtaqueSigiloso());
        register(ClassType.RANGER, 7, new EscapeRapido());

        // registro de paladín (paladin)
        register(ClassType.PALADIN, 1, new Curacion());
        register(ClassType.PALADIN, 2, new EscudoSagrado());
        register(ClassType.PALADIN, 3, new GolpeSagrado());
        register(ClassType.PALADIN, 4, new ProteccionDivina());
        register(ClassType.PALADIN, 5, new AuraCuracion());
        register(ClassType.PALADIN, 6, new JuicioDivino());
        register(ClassType.PALADIN, 7, new Resurreccion());
        // ladrón (rogue)
        register(ClassType.ROGUE, 1, new GolpeSigiloso());
        register(ClassType.ROGUE, 2, new CamuflajeRogue());
        register(ClassType.ROGUE, 3, new TrampaMortal());
        register(ClassType.ROGUE, 4, new Robo());
        register(ClassType.ROGUE, 5, new EscapeRapidoRogue());
        register(ClassType.ROGUE, 6, new AtaqueSorpresa());
        register(ClassType.ROGUE, 7, new Invisibilidad());
        // bardo (bard)
        register(ClassType.BARD, 1, new CancionCuracion());
        register(ClassType.BARD, 2, new MelodiaProteccion());
        register(ClassType.BARD, 3, new RitmoVelocidad());
        register(ClassType.BARD, 4, new Persuasion());
        register(ClassType.BARD, 5, new Ilusion());
        register(ClassType.BARD, 6, new AtaqueMusical());
        register(ClassType.BARD, 7, new Inspiracion());
        // bárbaro (barbarian)
        register(ClassType.BARBARIAN, 1, new GolpeBrutal());
        register(ClassType.BARBARIAN, 2, new FuriaBarbara());
        register(ClassType.BARBARIAN, 3, new CargaSalvaje());
        register(ClassType.BARBARIAN, 4, new RabiaCiegaBarbarian());
        register(ClassType.BARBARIAN, 5, new GolpeDemoledor());
        register(ClassType.BARBARIAN, 6, new ProteccionBarbara());
        register(ClassType.BARBARIAN, 7, new FuriaExtrema());
    }

    private void register(ClassType type, int slot, Skill skill) {
        skillRegistry.put(type.name() + "_" + slot, skill);
    }

    public Skill getSkill(ClassType type, int slot) {
        return skillRegistry.get(type.name() + "_" + slot);
    }
}