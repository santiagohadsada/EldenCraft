package com.tuusuario.mmo.eldencraft.skills.rogue;

import com.tuusuario.mmo.eldencraft.skills.Skill;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.Sound;

public class Invisibilidad implements Skill {
    @Override
    public String getName() { return "Invisibilidad"; }
    @Override
    public double getCost() { return 60.0; }
    @Override
    public int getLevelRequired() { return 20; }

    @Override
    public void execute(Player player, PlayerData data) {
        // Invisibilidad absoluta por 10 segundos
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 200, 1));
        player.playSound(player.getLocation(), Sound.ENTITY_ILLUSIONER_MIRROR_MOVE, 1f, 1f);
        player.sendMessage("§f§l» §7Te has vuelto completamente invisible.");

        player.getWorld().spawnParticle(Particle.LARGE_SMOKE,
                player.getLocation().add(0, 1, 0), 60, 0.7, 1.2, 0.7, 0.05);
        player.getWorld().spawnParticle(Particle.PORTAL,
                player.getLocation().add(0, 1, 0), 30, 0.5, 1.0, 0.5, 0.5);
    }
}
