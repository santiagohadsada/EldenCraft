package com.tuusuario.mmo.eldencraft.util;

import com.tuusuario.mmo.eldencraft.skills.Skill;

import java.util.HashMap;
import java.util.Map;

/**
 * Descripciones legibles de cada habilidad para el menú /skills.
 * La clave es el nombre SIMPLE de la clase Java (getClass().getSimpleName()).
 */
public final class SkillDescriptions {

    private static final Map<String, String> MAP = new HashMap<>();

    static {
        // ── MAGO ──────────────────────────────────────────────────────────────
        MAP.put("BolaFuego",        "Lanza una bola de fuego que explota al impacto. No destruye bloques. Nivel 1.");
        MAP.put("EscudoMagico",     "Genera un escudo arcano que absorbe daño y te envuelve en un aura azul. Nivel 3.");
        MAP.put("Teleportacion",    "Te teletransportas hasta el bloque al que apuntas (máx. 15 bloques). Nivel 6.");
        MAP.put("LluviaHielo",      "Invoca una lluvia helada que daña y ralentiza a todos los enemigos cercanos. Nivel 9.");
        MAP.put("ExplosionMagica",  "Detona una onda mágica devastadora a tu alrededor. Nivel 12.");
        MAP.put("CuracionMagica",   "Restaura una gran cantidad de vida consumiendo maná puro. Nivel 16.");
        MAP.put("TormentaElectrica","Invoca rayos sobre todos los enemigos en 10 bloques. Nivel 20.");

        // ── GUERRERO ──────────────────────────────────────────────────────────
        MAP.put("GolpePoderoso",    "Concentra tu fuerza para potenciar tu próximo ataque con daño extra. Nivel 1.");
        MAP.put("DefensaSolida",    "Adoptas una postura defensiva que reduce el daño recibido. Nivel 3.");
        MAP.put("CargaFuriosa",     "Te impulsas hacia adelante a gran velocidad derribando enemigos. Nivel 6.");
        MAP.put("EscudoProtector",  "Genera un escudo de absorción física que bloquea daño entrante. Nivel 9.");
        MAP.put("FuriaGuerrera",    "Postura de Combate: inmunidad absoluta al daño durante 8 segundos. Nivel 12.");
        MAP.put("SaltoCombate",     "Salto explosivo que daña a todos los enemigos al aterrizar. Nivel 16.");
        MAP.put("RabiaCiega",       "Contraataque: refleja el 50% del daño recibido durante 12 segundos. Nivel 20.");

        // ── EXPLORADOR (RANGER) ───────────────────────────────────────────────
        MAP.put("Rastreo",          "Agudizas tus sentidos: velocidad aumentada y mejor percepción. Nivel 1.");
        MAP.put("FlechaPrecisa",    "Dispara una flecha crítica de gran daño ignorando parte de la defensa. Nivel 3.");
        MAP.put("Camuflaje",        "Compañero Lobo: invoca 2 lobos aliados que combaten a tu lado durante 30s. Nivel 6.");
        MAP.put("TrampaCaza",       "Trampa Natural: coloca una trampa en el suelo que atrapa al primer hostil que se acerque (30s). Nivel 9.");
        MAP.put("VisionNocturna",   "Concédete visión nocturna prolongada para ver en la oscuridad. Nivel 12.");
        MAP.put("AtaqueSigiloso",   "Marca del Cazador: revela con brillo a todos los enemigos hostiles en 20 bloques durante 30s. Nivel 16.");
        MAP.put("EscapeRapido",     "Salto del Ciervo: gran salto + velocidad + caída suave para moverte por el terreno. Nivel 20.");

        // ── PALADÍN ───────────────────────────────────────────────────────────
        MAP.put("Curacion",         "Te curas instantáneamente con luz divina. Nivel 1.");
        MAP.put("EscudoSagrado",    "Crea un escudo sagrado que absorbe daño y te rodea de un aura dorada. Nivel 3.");
        MAP.put("GolpeSagrado",     "Libera energía divina en área dañando a todos los enemigos cercanos. Nivel 6.");
        MAP.put("ProteccionDivina", "Otorga resistencia al daño durante 10 segundos. Nivel 9.");
        MAP.put("AuraCuracion",     "Emites un aura sanadora que cura lentamente a todos los aliados cercanos. Nivel 12.");
        MAP.put("JuicioDivino",     "Castiga con rayos divinos a todos los enemigos a tu alrededor. Nivel 16.");
        MAP.put("Resurreccion",     "Tótem Divino: durante 5 minutos, el siguiente golpe mortal a ti o un aliado en 30 bloques será cancelado y el afectado se curará al 50% de vida. Nivel 20.");

        // ── LADRÓN (ROGUE) ────────────────────────────────────────────────────
        MAP.put("GolpeSigiloso",    "Apuñalas a un enemigo desde las sombras causando daño crítico. Nivel 1.");
        MAP.put("CamuflajeRogue",   "Te ocultas entre las sombras volviéndote invisible. Nivel 3.");
        MAP.put("TrampaMortal",     "Coloca una trampa explosiva en el suelo que daña a quien la active. Nivel 6.");
        MAP.put("Robo",             "Toxina Corrosiva: lanza veneno al enemigo más cercano en 8 bloques (Veneno II + Wither I + Lentitud II). Si ya está envenenado, añade daño extra según tu Destreza. Nivel 9.");
        MAP.put("EscapeRapidoRogue","Velocidad extrema para alejarte del combate rápidamente. Nivel 12.");
        MAP.put("AtaqueSorpresa",   "Ataque devastador por la espalda que multiplica el daño infligido. Nivel 16.");
        MAP.put("Invisibilidad",    "Invisibilidad total prolongada. Atacar o recibir daño la rompe. Nivel 20.");

        // ── BARDO ─────────────────────────────────────────────────────────────
        MAP.put("CancionCuracion",  "Canta una melodía curativa que restaura vida a todos los aliados cercanos. Nivel 1.");
        MAP.put("MelodiaProteccion","Melodía protectora que reduce el daño recibido por los aliados cercanos. Nivel 3.");
        MAP.put("RitmoVelocidad",   "Ritmo vibrante que otorga velocidad aumentada a ti y tus aliados. Nivel 6.");
        MAP.put("Persuasion",       "Aturde a enemigos cercanos (lentitud + debilidad). Los jefes, inmunes a pociones, reciben daño directo de notas musicales. Nivel 9.");
        MAP.put("Ilusion",          "Crea 3 clones tuyos (con tu skin y equipo) durante 8s. Los enemigos cercanos redirigen su ataque a los clones. Los clones son invulnerables y no dropean nada. Nivel 12.");
        MAP.put("AtaqueMusical",    "Lanza notas musicales hostiles que dañan a todos los enemigos cercanos. Nivel 16.");
        MAP.put("Inspiracion",      "Inspira a tus aliados otorgándoles fuerza y resistencia temporales. Nivel 20.");

        // ── BÁRBARO ───────────────────────────────────────────────────────────
        MAP.put("GolpeBrutal",      "Asesta un golpe demoledor al enemigo más cercano con gran fuerza bruta. Nivel 1.");
        MAP.put("FuriaBarbara",     "Entra en furia: fuerza y haste aumentados durante 15s. Tu cuerpo brilla rojo. Nivel 3.");
        MAP.put("CargaSalvaje",     "Te lanzas hacia adelante con fuerza salvaje embistiendo a todo a tu paso. Nivel 6.");
        MAP.put("RabiaCiegaBarbarian","Rabia Ciega: estado berserker con fuerza y velocidad extremas. Aura roja. Nivel 9.");
        MAP.put("GolpeDemoledor",   "Detona una onda expansiva mágica devastadora. No destruye bloques. Nivel 12.");
        MAP.put("ProteccionBarbara","Tu piel se endurece: resistencia al daño durante 15 segundos. Nivel 16.");
        MAP.put("FuriaExtrema",     "Furia definitiva: fuerza, velocidad y regeneración máximas. Brillo rojo intenso. Nivel 20.");
    }

    private SkillDescriptions() {}

    /** Devuelve la descripción para el menú /skills. */
    public static String get(Skill skill) {
        if (skill == null) return "Sin descripción.";
        String key = skill.getClass().getSimpleName();
        return MAP.getOrDefault(key, "Sin descripción.");
    }
}
