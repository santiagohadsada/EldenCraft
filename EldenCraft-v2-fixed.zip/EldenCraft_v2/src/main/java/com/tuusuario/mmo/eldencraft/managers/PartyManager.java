package com.tuusuario.mmo.eldencraft.managers;

import com.tuusuario.mmo.eldencraft.EldenCraft;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.*;

// Gestor de partidas (parties).
public class PartyManager {

    public static class Party {
        public final UUID leader;
        public final List<UUID> members = new ArrayList<>();

        public Party(UUID leader) {
            this.leader = leader;
            this.members.add(leader);
        }
    }

    private final EldenCraft plugin;

    // Mapa: UUID de cualquier miembro -> Party a la que pertenece.
    private final Map<UUID, Party> playerToParty = new HashMap<>();

    // Invitaciones pendientes: UUID del invitado -> UUID del lider que invita.
    private final Map<UUID, UUID> pendingInvites = new HashMap<>();

    // Distancia maxima en bloques para repartir EXP entre miembros (legacy, ya no se usa).
    public static final double XP_SHARE_RADIUS = 50.0;

    // Distancia maxima en bloques entre el ENEMIGO muerto y un miembro para que reciba parte del XP/oro (regla nueva).
    public static final double XP_SHARE_RADIUS_FROM_ENEMY = 25.0;

    // Porcentaje del XP/oro base que reciben los demas miembros (el matador siempre recibe 100%).
    public static final double SHARED_XP_RATIO = 0.6;

    public PartyManager(EldenCraft plugin) {
        this.plugin = plugin;
    }

    public Party getParty(UUID uuid) { return playerToParty.get(uuid); }

    public boolean isInParty(UUID uuid) { return playerToParty.containsKey(uuid); }

    // Crea una nueva party con el jugador como lider.
    public boolean createParty(Player leader) {
        if (isInParty(leader.getUniqueId())) {
            leader.sendMessage(ChatColor.RED + "Ya estas en una party. Usa /party leave primero.");
            return false;
        }
        Party p = new Party(leader.getUniqueId());
        playerToParty.put(leader.getUniqueId(), p);
        leader.sendMessage(ChatColor.GREEN + "✔ Party creada. Eres el lider. Usa "
                + ChatColor.YELLOW + "/party invite <jugador>" + ChatColor.GREEN + " para invitar.");
        return true;
    }

    // Envia una invitacion.
    public boolean invite(Player leader, Player target) {
        Party p = getParty(leader.getUniqueId());
        if (p == null || !p.leader.equals(leader.getUniqueId())) {
            leader.sendMessage(ChatColor.RED + "Solo el lider de la party puede invitar.");
            return false;
        }
        if (target.getUniqueId().equals(leader.getUniqueId())) {
            leader.sendMessage(ChatColor.RED + "No puedes invitarte a ti mismo.");
            return false;
        }
        if (isInParty(target.getUniqueId())) {
            leader.sendMessage(ChatColor.RED + target.getName() + " ya esta en una party.");
            return false;
        }
        pendingInvites.put(target.getUniqueId(), leader.getUniqueId());
        leader.sendMessage(ChatColor.GREEN + "✔ Invitacion enviada a " + ChatColor.YELLOW + target.getName());
        target.sendMessage(ChatColor.AQUA + "✦ " + leader.getName()
                + " te ha invitado a su party. Acepta con " + ChatColor.YELLOW + "/party accept");
        return true;
    }

    // El invitado acepta la ultima invitacion recibida.
    public boolean accept(Player invitee) {
        UUID leaderId = pendingInvites.remove(invitee.getUniqueId());
        if (leaderId == null) {
            invitee.sendMessage(ChatColor.RED + "No tienes invitaciones pendientes.");
            return false;
        }
        Party p = getParty(leaderId);
        if (p == null) {
            invitee.sendMessage(ChatColor.RED + "La party ya no existe.");
            return false;
        }
        if (isInParty(invitee.getUniqueId())) {
            invitee.sendMessage(ChatColor.RED + "Ya estas en una party.");
            return false;
        }
        p.members.add(invitee.getUniqueId());
        playerToParty.put(invitee.getUniqueId(), p);
        broadcast(p, ChatColor.GREEN + "✔ " + invitee.getName() + " se ha unido a la party.");
        return true;
    }

    // Salir de la party.
    public boolean leave(Player player) {
        Party p = getParty(player.getUniqueId());
        if (p == null) {
            player.sendMessage(ChatColor.RED + "No estas en ninguna party.");
            return false;
        }
        p.members.remove(player.getUniqueId());
        playerToParty.remove(player.getUniqueId());

        if (p.members.isEmpty()) {
            player.sendMessage(ChatColor.GRAY + "Has dejado la party (disuelta porque estaba vacia).");
            return true;
        }

        if (p.leader.equals(player.getUniqueId())) {
            // Transferir liderazgo al primer miembro restante
            UUID newLeader = p.members.get(0);
            Party newParty = new Party(newLeader);
            // Reusar miembros
            newParty.members.clear();
            newParty.members.addAll(p.members);
            for (UUID m : p.members) playerToParty.put(m, newParty);
            broadcast(newParty, ChatColor.YELLOW + "★ " + player.getName()
                    + " salio. Nuevo lider: " + Bukkit.getOfflinePlayer(newLeader).getName());
            player.sendMessage(ChatColor.GRAY + "Has dejado la party.");
            return true;
        }

        broadcast(p, ChatColor.GRAY + "✦ " + player.getName() + " ha dejado la party.");
        player.sendMessage(ChatColor.GRAY + "Has dejado la party.");
        return true;
    }

    // El lider expulsa a un miembro.
    public boolean kick(Player leader, Player target) {
        Party p = getParty(leader.getUniqueId());
        if (p == null || !p.leader.equals(leader.getUniqueId())) {
            leader.sendMessage(ChatColor.RED + "Solo el lider puede expulsar.");
            return false;
        }
        if (!p.members.contains(target.getUniqueId())) {
            leader.sendMessage(ChatColor.RED + target.getName() + " no esta en tu party.");
            return false;
        }
        if (target.getUniqueId().equals(leader.getUniqueId())) {
            leader.sendMessage(ChatColor.RED + "No puedes expulsarte a ti mismo. Usa /party disband.");
            return false;
        }
        p.members.remove(target.getUniqueId());
        playerToParty.remove(target.getUniqueId());
        target.sendMessage(ChatColor.RED + "✖ Has sido expulsado de la party por " + leader.getName() + ".");
        broadcast(p, ChatColor.YELLOW + "✦ " + target.getName() + " fue expulsado de la party.");
        return true;
    }

    // El lider disuelve la party completa.
    public boolean disband(Player leader) {
        Party p = getParty(leader.getUniqueId());
        if (p == null || !p.leader.equals(leader.getUniqueId())) {
            leader.sendMessage(ChatColor.RED + "Solo el lider puede disolver la party.");
            return false;
        }
        broadcast(p, ChatColor.RED + "✖ La party ha sido disuelta.");
        for (UUID id : new ArrayList<>(p.members)) {
            playerToParty.remove(id);
        }
        return true;
    }

    // Llamado al desconectar un jugador.
    public void handleQuit(UUID uuid) {
        pendingInvites.remove(uuid);
        // Tambien limpiar invitaciones que enviaba este jugador
        pendingInvites.entrySet().removeIf(e -> e.getValue().equals(uuid));

        Party p = getParty(uuid);
        if (p == null) return;

        p.members.remove(uuid);
        playerToParty.remove(uuid);

        if (p.members.isEmpty()) return;

        if (p.leader.equals(uuid)) {
            UUID newLeader = p.members.get(0);
            Party newParty = new Party(newLeader);
            newParty.members.clear();
            newParty.members.addAll(p.members);
            for (UUID m : p.members) playerToParty.put(m, newParty);
            broadcast(newParty, ChatColor.YELLOW + "★ El lider se desconecto. Nuevo lider: "
                    + Bukkit.getOfflinePlayer(newLeader).getName());
        }
    }

    // Lista de jugadores online de la party.
    public List<Player> getOnlineMembers(Party p) {
        List<Player> list = new ArrayList<>();
        for (UUID id : p.members) {
            Player pl = Bukkit.getPlayer(id);
            if (pl != null && pl.isOnline()) list.add(pl);
        }
        return list;
    }

    // Mensaje a todos los miembros online.
    public void broadcast(Party p, String msg) {
        for (Player pl : getOnlineMembers(p)) pl.sendMessage(msg);
    }

    public EldenCraft getPlugin() { return plugin; }
}
