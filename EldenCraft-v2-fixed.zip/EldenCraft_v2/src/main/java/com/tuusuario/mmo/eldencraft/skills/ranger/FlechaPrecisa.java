package com.tuusuario.mmo.eldencraft.skills.ranger;

import com.tuusuario.mmo.eldencraft.skills.Skill;
import com.tuusuario.mmo.eldencraft.models.PlayerData;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.Sound;

public class FlechaPrecisa implements Skill {
    @Override
    public String getName() { return "Flecha Precisa"; }
    @Override
    public double getCost() { return 20.0; }
    @Override
    public int getLevelRequired() { return 3; }

    @Override
    public void execute(Player player, PlayerData data) {
        Arrow arrow = player.launchProjectile(Arrow.class);
        // El daño de la flecha escala con Sabiduría y Destreza
        double extraDamage = (data.getDexterity() * 0.5) + (data.getWisdom() * 0.2);
        arrow.setDamage(5.0 + extraDamage);
        arrow.setCritical(true);
        player.playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1f, 1.5f);
    }
}